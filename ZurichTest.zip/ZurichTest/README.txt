Project - Automation Test Store

Tests:
Test 1 - Validate if Register or Login Page is displayed
Test 2 - Go to Register Page
Test 3 - Enter Register form details from the Excel sheet (src>test>resources>InputData>RegisterData.xlsx)

Use TestNG.xml to run the tests
Extent reports generated in Base folder - Reports
