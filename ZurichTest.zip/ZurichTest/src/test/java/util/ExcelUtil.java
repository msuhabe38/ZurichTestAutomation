package util;

import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.DateUtil;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

import java.io.File;
import java.util.HashMap;
import java.util.Map;

public class ExcelUtil {

    private static XSSFWorkbook wb;
    private static Sheet sheet;
    private static Cell cell;
    private static String excelFilePath;
    private static Map<String, Integer> columns = new HashMap<>();

    public static void setExcelFile(String ExcelPath, String SheetName) {
        try {
            File xlFile = new File(ExcelPath);
            if (xlFile.exists() && !xlFile.isDirectory()) {
                wb = new XSSFWorkbook(xlFile);
                sheet = wb.getSheet(SheetName);
                if (sheet != null) {
                    excelFilePath = ExcelPath;
                    //adding all the column header names to the map 'columns'
                    sheet.getRow(0).forEach(cell -> {
                        columns.put(cell.getStringCellValue(), cell.getColumnIndex());
                    });
                }
            }
        } catch (Exception e) {
            System.out.println(e.getMessage());
            throw new RuntimeException("Excel file error: " +e.getMessage());
        }
    }

    public static String getCellData(int rownum, int colnum) {
        try {
            cell = sheet.getRow(rownum).getCell(colnum);
            String CellData = null;
            switch (cell.getCellType()) {
                case STRING:
                    CellData = cell.getStringCellValue();
                    break;
                case NUMERIC:
                    if (DateUtil.isCellDateFormatted(cell)) {
                        CellData = String.valueOf(cell.getDateCellValue());
                    } else {
                        CellData = String.valueOf((long) cell.getNumericCellValue());
                    }
                    break;
                case BOOLEAN:
                    CellData = Boolean.toString(cell.getBooleanCellValue());
                    break;
                case BLANK:
                    CellData = "";
                    break;
            }
            return CellData;
        } catch (Exception e) {
            return "";
        }
    }

    public static String getCellData(String columnName, int rownum) {
        return getCellData(rownum, columns.get(columnName));
    }

}