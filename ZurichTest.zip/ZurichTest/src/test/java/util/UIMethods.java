package util;

import org.openqa.selenium.ElementNotInteractableException;
import org.openqa.selenium.StaleElementReferenceException;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;
import testcases.BaseTest;

import java.time.Duration;

public class UIMethods extends BaseTest {

    public static void clickElement(WebElement elem) {
        try {
            if (elem.isDisplayed()) {
                elem.click();
            }
        } catch (StaleElementReferenceException | ElementNotInteractableException exc) {
            throw new RuntimeException("Exception occurred on click action of element: " + elem);
        }
    }

    public static void sendKeys(WebElement elem, String value) {
        try {
            if (elem.isDisplayed()) {
                elem.sendKeys(value);
            }
        } catch (StaleElementReferenceException | ElementNotInteractableException exc) {
            throw new RuntimeException("Exception occurred on sendKeys action of element: " + elem);
        }
    }

    public static String getText(WebElement elem) {
        String elemText = null;
        try {
            if (elem.isDisplayed()) {
                elemText = elem.getText();
            }
        } catch (StaleElementReferenceException | ElementNotInteractableException exc) {
            throw new RuntimeException("Exception occurred on click action of element: " + elem);
        }
        return elemText;
    }


    public static void webDriverWait(WebElement elem) {
        try {
            WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(10));
            wait.until(ExpectedConditions.visibilityOf(elem));
        } catch (StaleElementReferenceException | ElementNotInteractableException exc) {
            throw new RuntimeException("Exception occurred on wait action of element: " + elem);
        }
    }

    public static void selectFromDropdown(WebElement elem) {
        try {
            if (elem.isDisplayed()) {
                Select countrySelect = new Select(elem);
                countrySelect.selectByIndex(2);
                try {
                    Thread.sleep(2000);
                } catch (InterruptedException e) {
                    throw new RuntimeException(e);
                }
            }
        } catch (StaleElementReferenceException | ElementNotInteractableException exc) {
            throw new RuntimeException("Exception occurred on sendKeys action of element: " + elem);
        }
    }

}
