package testcases;

import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.reporter.ExtentSparkReporter;
import org.apache.commons.io.FileUtils;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;

import java.io.File;
import java.io.IOException;
import java.nio.file.Path;
import java.util.Date;
import java.util.concurrent.TimeUnit;

public class BaseTest {

    public static WebDriver driver;
    public ExtentReports reports;
    public ExtentSparkReporter extentSpRpt;
    public static ExtentTest logger;
    public static String screenshotName;

    @BeforeTest
    public void setup() {
        System.setProperty("webdriver.chrome.driver", "C:\\Users\\User\\chromedriver\\chromedriver.exe");
        driver = new ChromeDriver();
        driver.manage().window().maximize();
        driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
        driver.get("https://automationteststore.com/");
        startTest();
    }

    @AfterTest
    public void terminate() {
        driver.quit();
        reports.flush();
    }

    public void startTest() {
        reports = new ExtentReports();
        String reportName = "extent-report" + System.currentTimeMillis();
        extentSpRpt = new ExtentSparkReporter(new File(System.getProperty("user.dir") + "\\Reports\\"+reportName+".html"));
        reports.attachReporter(extentSpRpt);
        logger = reports.createTest("Automation Test Store");
    }

    public static String captureScreenshotPath() {
        TakesScreenshot screenshot = (TakesScreenshot) driver;
        File src = screenshot.getScreenshotAs(OutputType.FILE);
        File screenshotFile = null;

        try {
            screenshotName = "Screenshot" + System.currentTimeMillis() + ".jpg";
            screenshotFile = new File(System.getProperty("user.dir") + "\\reports\\screenshots\\" + screenshotName);
            FileUtils.copyFile(src, screenshotFile);
            return String.valueOf(Path.of(screenshotFile.toURI()));
        } catch (IOException e) {
            System.out.println("Exception while taking screenshot " + e.getMessage());
            return "";
        }
    }

}
