package testcases;

import com.aventstack.extentreports.MediaEntityBuilder;
import org.testng.annotations.Test;
import pages.RegisterOrLoginPage;
import pages.RegisterPage;

public class RegisterTestcase extends BaseTest {

    RegisterOrLoginPage registerOrLoginPage;
    RegisterPage registerPage;

    @Test(priority = 1)
    public void validateRegisterOrLoginPageDisplayed() {
        registerOrLoginPage = new RegisterOrLoginPage(driver);
        if (!registerOrLoginPage.verifyRegisterOrLoginPage())
            logger.fail("Register or Login Page not loaded", MediaEntityBuilder.createScreenCaptureFromPath(captureScreenshotPath()).build());
        else
            logger.pass("Register or Login Page displayed Successfully");
    }

    @Test(priority = 2)
    public void gotoRegisterPage() {
        registerOrLoginPage = new RegisterOrLoginPage(driver);
        registerOrLoginPage.clickLoginOrRegisterButton();
        registerOrLoginPage.clickContinueButton();
    }

    @Test(priority = 3)
    public void registerUser() throws InterruptedException {
        registerPage = new RegisterPage(driver);
        registerPage.register();
        registerPage.verifyUserLoggedIn("Sandy");
    }

}
