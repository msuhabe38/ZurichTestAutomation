package pages;

import com.aventstack.extentreports.MediaEntityBuilder;
import com.aventstack.extentreports.Status;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import testcases.BaseTest;
import util.ExcelUtil;

import static util.UIMethods.*;

public class RegisterPage extends BaseTest {

    @FindBy(id = "AccountFrm_firstname")
    private WebElement fName;
    @FindBy(id = "AccountFrm_lastname")
    private WebElement lName;
    @FindBy(id = "AccountFrm_email")
    private WebElement eMail;
    @FindBy(id = "AccountFrm_address_1")
    private WebElement addr1;
    @FindBy(id = "AccountFrm_city")
    private WebElement city;
    @FindBy(id = "AccountFrm_zone_id")
    private WebElement zone;
    @FindBy(id = "AccountFrm_postcode")
    private WebElement postalCode;
    @FindBy(id = "AccountFrm_country_id")
    private WebElement country;
    @FindBy(id = "AccountFrm_loginname")
    private WebElement loginName;
    @FindBy(id = "AccountFrm_password")
    private WebElement loginPswd;
    @FindBy(id = "AccountFrm_confirm")
    private WebElement ConfirmPswd;
    @FindBy(id = "AccountFrm_agree")
    private WebElement AgreeCheckbox;
    @FindBy(xpath = "//button[@title='Continue']")
    private WebElement ContinueBtn;
    @FindBy(xpath = "//span[@class='maintext']")
    private WebElement mainText;
    @FindBy(xpath = "//div[contains(text(),'Welcome back')]")
    private WebElement welcomeBackText;


    public RegisterPage(WebDriver driver) {
        this.driver = driver;
        PageFactory.initElements(driver, this);
    }


    public void register() throws InterruptedException {

        ExcelUtil.setExcelFile(System.getProperty("user.dir") + "\\src\\test\\resources\\InputData\\RegisterData.xlsx", "Register");

        sendKeys(fName, ExcelUtil.getCellData("First Name", 1));
        sendKeys(lName, ExcelUtil.getCellData("Last Name", 1));
        sendKeys(eMail, ExcelUtil.getCellData("Email Id", 1));
        sendKeys(addr1, ExcelUtil.getCellData("Address Line 1", 1));
        sendKeys(city, ExcelUtil.getCellData("City", 1));
        selectFromDropdown(country);
        selectFromDropdown(zone);
        sendKeys(postalCode, ExcelUtil.getCellData("Postal Code", 1));
        sendKeys(loginName, ExcelUtil.getCellData("Login Name", 1));
        sendKeys(loginPswd, ExcelUtil.getCellData("Login Password", 1));
        sendKeys(ConfirmPswd, ExcelUtil.getCellData("Login Password", 1));
        clickElement(AgreeCheckbox);
        clickElement(ContinueBtn);

        webDriverWait(mainText);
        if (getText(mainText).trim().equals("YOUR ACCOUNT HAS BEEN CREATED!")) {
            logger.log(Status.PASS, "Account Created Successfully");
        } else {
            logger.log(Status.FAIL, "Failed to Create Account", MediaEntityBuilder.createScreenCaptureFromPath(captureScreenshotPath()).build());
        }

    }

    public void verifyUserLoggedIn(String fName) {
        if (getText(welcomeBackText).contains(fName)) {
            logger.log(Status.PASS, "User Name displayed correctly after creating New user");
        } else {
            logger.log(Status.FAIL, "User Name not displayed correctly after creating New user", MediaEntityBuilder.createScreenCaptureFromPath(captureScreenshotPath()).build());
        }
    }

}
