package pages;

import com.aventstack.extentreports.Status;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import testcases.BaseTest;

import static util.UIMethods.clickElement;
import static util.UIMethods.webDriverWait;

public class RegisterOrLoginPage extends BaseTest {

    @FindBy(xpath = "//a[text()='Login or register']")
    private WebElement loginOrRegisterLink;

    @FindBy(xpath = "//div[contains(@class,'newcustomer')]/h2")
    private WebElement newCustomerLink;

    @FindBy(xpath = "//button[@title='Continue']")
    private WebElement continueBtn;

    @FindBy(id = "AccountFrm_firstname")
    private WebElement firstname;

    public RegisterOrLoginPage(WebDriver driver) {
        this.driver = driver;
        PageFactory.initElements(driver, this);
    }

    public boolean verifyRegisterOrLoginPage() {
        webDriverWait(loginOrRegisterLink);
        if (driver.getTitle().equals("A place to practice your automation skills!")) {
            return true;
        } else {
            return false;
        }
    }

    public void clickLoginOrRegisterButton() {
        clickElement(loginOrRegisterLink);
        logger.log(Status.PASS, "Clicked on Login or Register Button");
        webDriverWait(newCustomerLink);
    }

    public void clickContinueButton() {
        clickElement(continueBtn);
        logger.log(Status.PASS, "Clicked on Continue Button");
        webDriverWait(firstname);
    }

}
